@Component({
  selector: 'app-lista-clinicas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lista-clinicas.component.html',
  styleUrls: ['./lista-clinicas.component.css']
})
export class ListaClinicasComponent {}
