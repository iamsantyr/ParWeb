import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ClinicaService } from '../../services/clinica.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-form-clinica',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './form-clinica.component.html',
  styleUrl: './form-clinica.component.css'
})
export class FormClinicaComponent {

  clinica: any = {
    nombre: '',
    direccion: '',
    telefono: '',
    ciudad: ''
  };

  constructor(private clinicaService: ClinicaService, private router: Router) {}

  guardar() {
    this.clinicaService.crear(this.clinica).subscribe({
      next: () => this.router.navigate(['/clinicas']),
      error: err => console.error(err)
    });
  }
}
