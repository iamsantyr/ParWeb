export interface Clinica {
  id?: number;
  nombre: string;
  direccion?: string;
  telefono?: string;
  ciudad?: string;
}
