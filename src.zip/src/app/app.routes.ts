import { Routes } from '@angular/router';
import { ListaClinicasComponent } from './components/lista-clinicas/lista-clinicas.component';
import { FormClinicaComponent } from './components/form-clinica/form-clinica.component';

export const routes: Routes = [
  { path: '', redirectTo: 'clinicas', pathMatch: 'full' },
  { path: 'clinicas', component: ListaClinicasComponent },
  { path: 'nueva-clinica', component: FormClinicaComponent },
];
